# Maalavo Store V31

- `frontend/` — основной магазин.
- `admin/` — отдельный сайт админки.
- `backend/` — Express + PostgreSQL API для Railway.

## Frontend
Внутри `frontend/` сохранены исходные HTML/CSS/JS, изображения товаров и документы.

## Admin
`admin/index.html` — отдельная админка, авторизация выполняется backend через `/api/admin/login`.

## Backend
Деплой директории `backend/` на Railway. Секреты задаются только через environment variables.
